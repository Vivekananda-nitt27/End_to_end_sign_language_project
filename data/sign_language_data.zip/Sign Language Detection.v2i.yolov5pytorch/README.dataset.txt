# Sign Language Detection  > 2024-03-31 4:01pm
https://universe.roboflow.com/ml-uaeg0/sign-language-detection-w5fu0

Provided by a Roboflow user
License: CC BY 4.0

